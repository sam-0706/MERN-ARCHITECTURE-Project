An Nft market developed using MERN architecture
