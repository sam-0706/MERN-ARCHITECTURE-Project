import "./SolutionsScreen.css";
import React from 'react';


const SolutionsScreen = () => {
      return (
      <div className="solutions-screen">
        <h1 className="solutions-screen-title">Use Cases</h1>
        <div className="solutions-screen-content">
          <p>The best market to buy NFTS </p>
          </div>
      </div>
    );
  };
  
  
  export { SolutionsScreen };