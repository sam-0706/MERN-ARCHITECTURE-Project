import "./DiscountsScreen.css";
import React from 'react';


const DiscountsScreen = () => {
    return (
      <div className="discounts-screen">
        <h1 className="discounts-screen-title">Discounts</h1>
        <div className="discounts-screen-content">
          <p>The discounts are given given on a daily basis</p>
        </div>
      </div>
    );
  };
  
  
  export { DiscountsScreen };